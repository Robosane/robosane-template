# Robosane's Joomla Website Template
Robosane's Top-Secret new Website Appearance,  
But it's not so secret anymore.  

Features:
 * Correct Twitter cards for Article Pages
 * Mobile native experience
 * Desktop all resolution support
 * Bootstrap based, modern coding standards.
 * Best experienced in Chrome, all platforms

Before using this, be sure to TEST IT and ask me. I have only ever tested this template on https://robosane.net/

All bootstrap override CSS is mainly in css/robosane.css
If needed, the template includes it's own versions of bootstrap and jQuery that are known to work, simply switch the includes in index.php if needed.
