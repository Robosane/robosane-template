# Robosane's Joomla Website Template
Robosane's Top-Secret new Website Appearance,  
But it's not so secret anymore.  

View how it looks at https://robosane.net/

Features:
 * Twitter Cards support!
 * Mobile native experience
 * Desktop all resolution support
 * Bootstrap based, up-to-date standards
 * Designed with help from Chrome Dev Tools
 * Works in most browsers (darn IE)

Before putting this onto a live site, you'll probably want to go through a few tests, as there are numerous options and settings that should be configured for the template to look like it should.

All bootstrap override CSS is mainly in css/robosane.css
If needed, the template includes it's own versions of bootstrap and jQuery that are known to work, simply switch the includes in index.php if the Joomla ones don't work.

TLDR Legal things:
---
(Mozilla License)
 * This project includes Robosane branding and imagery. If you wish to use this NOT on behalf of Robosane, you must remove this branding from the template.
 * You are free to use this template in a personal and commercial setting, and you may make any modifications you see fit. If you distribute this template, you are required to include the source code. (Which should be easy considering it is all web-content.)
 * Although not explicitly required, if you could give me some credit when using this template, it would be much appreciated!
